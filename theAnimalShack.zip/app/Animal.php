<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Animal extends Model
{
    protected $fillable = ['name','species', 'description'];
    /**
     * [files description]
     * @return [type] [description]
     */
    public function files()
    {
    	return $this->hasMany(File::class,'animal_id');
    }
    
    /**
     * [firstFile description]
     * @return [type] [description]
     */
    public function firstFile()
    {
    	return $this->files->first()->file;
    }
}
