<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adoptRequest extends Model
{
    //
}
