<?php
	$user = \App\User::find(request('id'));
?>


<!-- This blade.php page displays all requests to staff, and displays requests that the specific user has made to users-->
<?php $__env->startSection('content'); ?>

<!-- display the errors -->
<?php if($errors->any()): ?>
<div class="alert alert-danger">
  <ul> <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div><br /> <?php endif; ?>
<!-- display the success status -->
<?php if(\Session::has('success')): ?>
<div class="alert alert-success">
  <p><?php echo e(\Session::get('success')); ?></p>
</div><br /> <?php endif; ?>
<!-- display the warning status -->
<?php if(\Session::has('warning')): ?>
<div class="alert alert-warning">
  <p><?php echo e(\Session::get('warning')); ?></p>
</div><br /> <?php endif; ?>


<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 ">
    	<div class="card">
    	  <div class="card-header">User profile</div>
    	  <div class="card-body">
    	   <table class="table table-bordered">
    	   	<tr>
    	   		<th>ID</th>
    	   		<td><?php echo e($user->id); ?></td>
    	   	</tr>
    	   	<tr>
    	   		<th>Name</th>
    	   		<td><?php echo e($user->name); ?></td>
    	   	</tr>
    	   	<tr>
    	   		<th>Email</th>
    	   		<td><?php echo e($user->email); ?></td>
    	   	</tr>
    	   	
    	   </table>
    	  </div>
    	</div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\2021\IATCoursework-master\theAnimalShack\resources\views/user-profile.blade.php ENDPATH**/ ?>