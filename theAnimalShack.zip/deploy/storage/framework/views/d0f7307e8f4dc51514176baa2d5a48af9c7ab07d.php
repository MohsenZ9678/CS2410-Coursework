<!-- This blade.php page displays all animals to staff, and displays all available animals to users-->
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 ">
      #<?php if(auth()->guard()->guest()): ?>
      <div class="card">
        <div class="card-header">Error</div>
        <div class="card-body">
          <p>You do not have access to this page</p>
        </div>
      </div>
      <?php else: ?>
      <?php if(Auth::user()->role == 1): ?>
      <div class="card">
        <div class="card-header">Display all Animals</div>
        <div class="card-body">
          <form>
            Filter by Pet Type:
            <select name="type">
              <option value="">All</option>
              <option value="Dog">Dog</option>
              <option value="Cat">Cat</option>
              <option value="Aquarium">Aquarium</option>
              <option value="Bird">Bird</option>
              <option value="Mammal">Mammal</option>
              <option value="Rodent">Rodent</option>
              <option value="Reptile">Reptile</option>
              <option value="Amphiban">Amphibian</option>
              <option value="Horse">Horse</option>
            </select>
            <input type="submit" value="Filter" /> 
          </form>
          <table class="table table-striped table-dark">
            <thead>
              <tr>
                <th>Name</th>
                <th>Species</th>
                <th>DOB</th>
                <th>Image</th>

                <th colspan="3">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>

                <td><?php echo e($animal['name']); ?></td>
                <td><?php echo e($animal['species']); ?></td>
                <td><?php echo e($animal['dob']); ?></td>
                <td>
                  <?php $__currentLoopData = $animal->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                  <img style="width:60px;"src="<?php echo e(asset(''.$file->file)); ?>">
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                  <td><a href="<?php echo e(action('AnimalController@show', $animal['id'])); ?>" class="btn
                    btn-primary">Details</a></td>

                    <?php if(Auth::user()->role == 1): ?>

                    <td><a href="<?php echo e(action('AnimalController@edit', $animal['id'])); ?>" class="btn
                      btn-warning">Edit</a>
                    </td>

                    <td>
                      <form action="<?php echo e(action('AnimalController@destroy', $animal['id'])); ?>"
                      method="post"> <?php echo csrf_field(); ?>
                      <input name="_method" type="hidden" value="DELETE">
                      <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                  </td>

                  <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
        <?php else: ?>


        <div class="card">
          <div class="card-header">Display Available Animals</div>
          <div class="card-body">
            <table class="table table-striped table-dark">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Species</th>
                  <th>DOB</th>

                  <th>Image</th>

                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($animal["adoptionStatus"] == 0): ?>

                <tr>

                  <td><?php echo e($animal['name']); ?></td>
                  <td><?php echo e($animal['species']); ?></td>
                  <td><?php echo e($animal['dob']); ?></td>

                  <td><?php $__currentLoopData = $animal->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                  <img style="width:60px;"src="<?php echo e(asset(''.$file->file)); ?>">
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>

                    <td><a href="<?php echo e(action('AnimalController@show', $animal['id'])); ?>" class="btn
                      btn-primary">Details</a></td>

                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>

                    </div>
                  </div>
                  <?php endif; ?>
                </div>
                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\2021\IATCoursework-master\theAnimalShack\resources\views/animals/index.blade.php ENDPATH**/ ?>