<!-- This blade.php page shows one specific animal from the list-->
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 ">
      <?php if(auth()->guard()->guest()): ?>
      <div class="card">
        <div class="card-header">Error</div>
        <div class="card-body">
          <p>You do not have access to this page</p>
        </div>
      </div>
      <?php else: ?>
      <!-- display the errors -->
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul> <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br /> <?php endif; ?>
      <!-- display the success status -->
      <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
      </div><br /> <?php endif; ?>
      <div class="card">
        <div class="card-header">Animals</div>
        <div class="card-body">
          <table class="table table-striped table-dark" border="1" >
            <tr> <td> <b>Name </th> <td> <?php echo e($animal['name']); ?></td></tr>
              <tr> <th>Species </th> <td><?php echo e($animal->species); ?></td></tr>
              <tr> <th>DOB </th> <td><?php echo e($animal->dob); ?></td></tr>
              <tr> <th>Description</th> <td style="max-width:150px;" ><?php echo e($animal->description); ?></td></tr>
              <tr> <td colspan='2' >
                <?php $__currentLoopData = $animal->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                  <img style="width:60px;"src="<?php echo e(asset('public/'.$file->file)); ?>">
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </td></tr>
              </table>
              <table><tr>
                <td><a href="../animals" class="btn btn-primary" role="button">Back to the list</a></td>

                <?php if(Auth::user()->role == 0): ?>
                <td><a href="<?php echo e(action('AdoptRequestController@submitRequest', $animal['id'])); ?>" class="btn btn-success" role="button">Submit Adoption Request</a></td>
                <?php endif; ?>
                <?php if(Auth::user()->role == 1): ?>
                <td><a href="<?php echo e(action('AnimalController@edit', $animal['id'])); ?>" class="btn btn-warning">Edit</a></td>
                <td><form action="<?php echo e(action('AnimalController@destroy', $animal['id'])); ?>"
                  method="post"> <?php echo csrf_field(); ?>
                  <input name="_method" type="hidden" value="DELETE">
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form></td>
                <?php endif; ?>
              </tr></table>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\2021\IATCoursework-master\theAnimalShack\deploy\resources\views/animals/show.blade.php ENDPATH**/ ?>