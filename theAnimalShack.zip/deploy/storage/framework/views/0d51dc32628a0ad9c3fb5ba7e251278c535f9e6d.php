<!-- This blade.php page displays all requests to staff, and displays requests that the specific user has made to users-->
<?php $__env->startSection('content'); ?>

<!-- display the errors -->
<?php if($errors->any()): ?>
<div class="alert alert-danger">
  <ul> <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div><br /> <?php endif; ?>
<!-- display the success status -->
<?php if(\Session::has('success')): ?>
<div class="alert alert-success">
  <p><?php echo e(\Session::get('success')); ?></p>
</div><br /> <?php endif; ?>
<!-- display the warning status -->
<?php if(\Session::has('warning')): ?>
<div class="alert alert-warning">
  <p><?php echo e(\Session::get('warning')); ?></p>
</div><br /> <?php endif; ?>


<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 ">
      <!-- below is code for displaying adoption request  -->

      <?php if(auth()->guard()->guest()): ?>
      <div class="card">
        <div class="card-header">Error</div>
        <div class="card-body">
          <p>You do not have access to this page</p>
        </div>
      </div>
      <?php else: ?>

      <?php if(Auth::user()->role == 1): ?>
      <div class="card">
        <div class="card-header">Display All Requests</div>
        <div class="card-body">
          <table class="table table-striped table-dark">
            <thead>
              <tr>
                <th>Adoption ID</th>
                <th>User ID</th>
                <th>Animal ID</th>
                <th>Animal Name</th>
                <th>Status</th>
                <th>Owner</th>
                <th>Details</th>
                <th colspan="2">Action</th>

              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $adoptRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adoptRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($adoptRequest["animalID"]==$animal["id"]): ?>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($adoptRequest["userid"]==$user["id"]): ?>

              <tr>
                <!--  edit below -->
                <td><?php echo e($adoptRequest['id']); ?></td>
                <td><?php echo e($adoptRequest['userid']); ?></td>
                <td><?php echo e($adoptRequest['animalID']); ?></td>
                <td><?php echo e($animal['name']); ?></td>
                <td><?php echo e($adoptRequest['adoptionStatus']); ?></td>
                <td><?php echo e($user['name']); ?> <a href="<?php echo e(route('user.show',$user['id'])); ?>" class="btn btn-sm btn-outline-info">View Profile</a></td>

                <!-- edit above -->
                <td><a href="<?php echo e(action('Admin\AnimalController@show', $animal['id'])); ?>" class="btn
                  btn-primary">Details</a></td>


                  <?php if($adoptRequest['adoptionStatus'] == 'Pending'): ?>


                  <td><a href="<?php echo e(action('AdoptRequestController@approveRequest', $adoptRequest['id'])); ?>" class="btn
                    btn-warning">Approve</a>
                  </td>


                  <td>
                    <a href="<?php echo e(action('AdoptRequestController@denyRequest', $adoptRequest['id'])); ?>" class="btn
                    btn-danger">Deny</a>
                  </td>
                  <?php endif; ?>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        </div>
        <?php else: ?>
        <!-- below is code for displaying users adoption requests  -->


        <div class="card">
          <div class="card-header">Display My Requests </div>
          <div class="card-body">
            <table class="table table-striped table-dark">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Species</th>
                  <th>DOB</th>
                  <th>Description</th>
                  <th>Status</th>


                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $adoptRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adoptRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($adoptRequest["userid"]==Auth::user()->id): ?>
                <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- below allows to use animals table and requests table together, checks that we're looking at the same animal, the right one.  -->
                <?php if($adoptRequest["animalID"]==$animal["id"]): ?>



                <tr>
                  <!--  edit below -->
                  <td><?php echo e($animal['name']); ?></td>
                  <td><?php echo e($animal['species']); ?></td>
                  <td><?php echo e($animal['dob']); ?></td>
                  <td><?php echo e($animal['description']); ?></td>
                  <td><?php echo e($adoptRequest['adoptionStatus']); ?></td>
                  <?php if($adoptRequest['adoptionStatus'] == 'Pending'): ?>
                  <td>
                    <form action="<?php echo e(action('AdoptRequestController@destroy', $adoptRequest['id'])); ?>"
                    method="post"> <?php echo csrf_field(); ?>
                    <input name="_method" type="hidden" value="DELETE">
                    <button class="btn btn-danger" type="submit">Remove Request</button>
                  </form>
                </td>
                <?php endif; ?>
              </tr>

              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\2021\IATCoursework-master\theAnimalShack\deploy\resources\views/requests/index.blade.php ENDPATH**/ ?>