<!-- This blade.php page edits the animal object-->
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 ">
      <?php if(auth()->guard()->guest()): ?>
      <div class="card">
        <div class="card-header">Error</div>
        <div class="card-body">
          <p>You do not have access to this page</p>
        </div>
      </div>
      <?php else: ?>
      <?php if(Auth::user()->role==1): ?>
      <div class="card">
        <div class="card-header">Edit and update the animal</div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div><br />
        <?php endif; ?>
        <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
          <p><?php echo e(\Session::get('success')); ?></p>
        </div><br />
        <?php endif; ?>
        <div class="card-body">
          <form class="form-horizontal" method="POST" action="<?php echo e(action('AnimalController@update',
          $animal['id'])); ?> " enctype="multipart/form-data" >
          <?php echo method_field('PATCH'); ?>
          <?php echo csrf_field(); ?>
          <div class="col-md-8">
            <label >Name</label>
            <input type="text" name="name"
            placeholder="name" value="<?php echo e($animal->name); ?>" />
          </div>
          <div class="col-md-8">
            <label>Species</label>
            <select name="species" >
              <option value="cat">Cat</option>
              <option value="dog">Dog</option>
              <option value="hamster">Hamster</option>
              <option value="goldfish">GoldFish</option>
              <option value="mouse">Mouse</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div class="col-md-8">
            <label >DOB</label>
            <input type="date" name="dob"
            placeholder="dob" value="<?php echo e($animal->dob); ?>" />
          </div>
          <div class="col-md-8">
            <label >Description</label>
            <textarea rows="4" cols="50" name="description" ><?php echo e($animal->description); ?></textarea>
          </div>
          <div class="col-md-8">

            <?php $__currentLoopData = $animal->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                  <img style="width:60px;"src="<?php echo e(asset(''.$file->file)); ?>">
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <label>Image</label>
            <input type="file" name="images[]" multiple />
          </div>
          <div class="col-md-6 col-md-offset-4">
            <input type="submit" class="btn btn-primary" />
            <input type="reset" class="btn btn-primary" />
          </a>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\2021\IATCoursework-master\theAnimalShack\resources\views/animals/edit.blade.php ENDPATH**/ ?>