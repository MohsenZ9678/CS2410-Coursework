<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <?php if(auth()->guard()->guest()): ?>
      Cannot Access
      <?php else: ?>
      <div class="card">
        <div class="card-header">My Profile</div>

        <div class="card-body">
          <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

          </div>
          <?php endif; ?>
          <?php
          $user = Auth::user()->name;
          print "Hello " . $user . ". Welcome to your homepage" . "<br />";
          ?>
          This is Aston Animal Sanctuary. Take a look and adopt yourself a pet today.
        </div>
      </div>
      <?php if(Auth::user()->role == 1): ?>

      <div class="card">
        <div class="card-header">Display All Pending Requests</div>
        <div class="card-body">
          <table class="table table-striped table-dark">
            <thead>
              <tr>
                <th>Adoption ID</th>
                <th>User ID</th>
                <th>Animal ID</th>
                <th>Animal Name</th>
                <th>Status</th>
                <th>Details</th>
                <th colspan="2">Action</th>

              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $adoptRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adoptRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($adoptRequest["animalID"]==$animal["id"]): ?>
              <?php if($adoptRequest["adoptionStatus"]==("Pending")): ?>


              <tr>
                <!--  edit below -->
                <td><?php echo e($adoptRequest['id']); ?></td>
                <td><?php echo e($adoptRequest['id']); ?></td>
                <td><?php echo e($adoptRequest['animalID']); ?></td>
                <td><?php echo e($animal['name']); ?></td>
                <td><?php echo e($adoptRequest['adoptionStatus']); ?></td>
                <!-- edit above -->
                <td><a href="<?php echo e(action('AnimalController@show', $animal['id'])); ?>" class="btn
                  btn-primary">Details</a></td>


                  <?php if($adoptRequest['adoptionStatus'] == 'Pending'): ?>

                  <td><a href="<?php echo e(action('AdoptRequestController@approveRequest', $adoptRequest['id'])); ?>" class="btn
                    btn-warning">Approve</a>
                  </td>


                  <td>
                    <a href="<?php echo e(action('AdoptRequestController@denyRequest', $adoptRequest['id'])); ?>" class="btn
                    btn-danger">Deny</a>
                  </td>
                  <?php endif; ?>
                  <!-- edit above -->
                  <?php endif; ?>
                  <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        </div>


        <?php else: ?>
        <div class="card">
          <div class="card-header">Here are the pets you have adopted.</div>
          <div class="card-body">
            <table class="table table-striped table-dark">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Species</th>
                  <th>DOB</th>

                  <th>Description</th>
                  <th>Image</th>

                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $adoptRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adoptRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($adoptRequest["userid"]==Auth::user()->id): ?>
                <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($adoptRequest["animalID"]==$animal["id"]): ?>
                <?php if($adoptRequest["adoptionStatus"]=='Accepted'): ?>
                <tr>

                  <td><?php echo e($animal['name']); ?></td>
                  <td><?php echo e($animal['species']); ?></td>
                  <td><?php echo e($animal['dob']); ?></td>
                  <td><?php echo e($animal['description']); ?></td>
                  <td><img style="width:100%;height:100%"
                    src="<?php echo e(asset('storage/images/'.$animal['image'])); ?>"></td>

                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>

                <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\2021\IATCoursework-master\theAnimalShack\resources\views/home.blade.php ENDPATH**/ ?>