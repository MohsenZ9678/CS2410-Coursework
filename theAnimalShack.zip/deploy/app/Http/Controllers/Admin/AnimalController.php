<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Animal;
use App\File;
use Illuminate\Http\Request;

class AnimalController extends Controller
{
  /**
  * Display a listing of the resource.
  *
  * @return \Illuminate\Http\Response
  */
  public function index()
  {
    if(request()->has('type') && request()->type != ''){
            $animals = Animal::where('species', request('type'))->get();
        } else{
            $animals = Animal::all();
        }

    return view('admin.animals.index', compact('animals'));
  }

  /**
  * Show the form for creating a new resource.
  *
  * @return \Illuminate\Http\Response
  */
  public function create()
  {
    return view('admin.animals.create');
  }

  /**
  * Store a newly created resource in storage.
  *
  * @param  \Illuminate\Http\Request  $request
  * @return \Illuminate\Http\Response
  */
  public function store(Request $request)
  {
    // form validation
    $animal = $this->validate(request(), [
      'name' => 'required',
      'species' => 'required',
      'image' => 'sometimes|image|mimes:jpeg,png,jpg,gif,svg|max:500',
    ]);
    //Handles the uploading of the image
    
    // create a Animal object and set its values from the input
    $animal = new Animal;
    $animal->name = $request->input('name');
    $animal->description = $request->input('description');
    $animal->dob = $request->input('dob');
    $animal->species= $request->input('species');
    $animal->created_at = now();
    $animal->image = '';
    // save the Animal object
    $animal->save();

    if (!is_null($request->images)) {
            foreach($request->file('images') as $image) {
                $name = $image->getClientOriginalName();
                $image->move(public_path('/images'), $name);
                \App\File::create([
                    'file' => '/images/'.$name,
                    'animal_id' => $animal->id
                  ]);
            }
         }

    // generate a redirect HTTP response with a success message
    return back()->with('success', 'Animal has been added');
  }

  /**
  * Display the specified resource.
  *
  * @param  int  $id
  * @return \Illuminate\Http\Response
  */
  public function show($id)
  {
    $animal = Animal::find($id);
    return view('admin.animals.show',compact('animal'));
  }

  /**
  * Show the form for editing the specified resource.
  *
  * @param  int  $id
  * @return \Illuminate\Http\Response
  */
  public function edit($id)
  {
    $animal = Animal::find($id);
    return view('admin.animals.edit',compact('animal'));
  }

  /**
  * Update the specified resource in storage.
  *
  * @param  \Illuminate\Http\Request  $request
  * @param  int  $id
  * @return \Illuminate\Http\Response
  */
  public function update(Request $request, $id)
  {
    $animal = Animal::find($id);
    $this->validate(request(), [
      'name' => 'required',
      'species' => 'required'
    ]);
    $animal->name = $request->input('name');
    $animal->description = $request->input('description');
    $animal->dob = $request->input('dob');
    $animal->species = $request->input('species');
    $animal->updated_at = now();
    //Handles the uploading of the image
    
    if (!is_null($request->images)) {
            $animal->files()->delete();
            foreach($request->file('images') as $image) {
                $name = $image->getClientOriginalName();
                $image->move(public_path('/images'), $name);
                File::create([
                    'file' => '/images/'.$name,
                    'animal_id' => $animal->id
                  ]);
            }
         }
    return redirect('animals')->with('success','Animal has been updated');
  }

  /**
  * Remove the specified resource from storage.
  *
  * @param  int  $id
  * @return \Illuminate\Http\Response
  */
  public function destroy($id)
  {

    \DB::table('adopt_requests')->where('animalID',$id)->delete();
    $animal = Animal::find($id);
    $animal->delete();
    return redirect('animals')->with('success','Animal has been deleted');
  }
}
