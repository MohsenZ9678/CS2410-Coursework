<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>The Animal Shack</title>

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">

  <!-- Styles -->
  <style>
  html, body {
    /*background-color: #fff;*/
    /*background-image: url("https://cdn.mos.cms.futurecdn.net/FUE7XiFApEqWZQ85wYcAfM.jpg");*/
    /*color: #636b6f;*/
    /*font-family: 'Indie Flower', cursive;*/
    font-weight: 200;
    height: 100vh;
    margin: 0;
  }

  .full-height {
    /*height: 100vh;*/
  }

  .flex-center {
    align-items: center;
    display: flex;
    justify-content: center;
  }

  .position-ref {
    position: relative;
  }

  .top-right {
    position: absolute;
    right: 10px;
    top: 18px;
  }

  .content {
    text-align: center;
  }

  .title {
    font-size: 84px;
    /*color: #fff;*/
  }

  .links > a {
    /*color: #fff;*/
    padding: 0 25px;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: .1rem;
    text-decoration: none;
    text-transform: uppercase;
  }

  .m-b-md {
    margin-bottom: 30px;
  }


  </style>
    <link href="{{ asset('public/css/app.css') }}" rel="stylesheet">
</head>
<body>
  <div class="flex-center position-ref full-height">
    @if (Route::has('login'))
    <div class="top-right links ">
      @auth
      <a href="{{ url('/home') }}">Home</a>
      @else
      <a href="{{ route('login') }}">Login</a>

      @if (Route::has('register'))
      <a href="{{ route('register') }}">Register</a>
      @endif
      @endauth
    </div>
    @endif

    <div class="content mt-4">
      <div class="title m-b-md mt-5">
        Aston Animal Sanctuary
      </div>
      
     <div class="container">
        <div class="row">
        @foreach (\App\Animal::all() as $animal)
          <div class="col-md-3">
            <div class="card">
                <img src="{{ asset('public/'.$animal->firstFile())}}" class="card-img-top" style="max-height: 140px" alt="...">

              <div class="card-body">
                
                 <p class="card-text">{{ $animal->name }}</p>
    <a href="/animals/{{ $animal->id }}" class="btn btn-primary">View</a>
              </div>
            </div>
        </div>
        @endforeach
      </div>
     </div>


    </div>
  </div>
</body>
</html>
