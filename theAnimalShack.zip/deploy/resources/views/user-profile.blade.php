@php
	$user = \App\User::find(request('id'));
@endphp

@extends('layouts.app')
<!-- This blade.php page displays all requests to staff, and displays requests that the specific user has made to users-->
@section('content')

<!-- display the errors -->
@if ($errors->any())
<div class="alert alert-danger">
  <ul> @foreach ($errors->all() as $error)
    <li>{{ $error }}</li> @endforeach
  </ul>
</div><br /> @endif
<!-- display the success status -->
@if (\Session::has('success'))
<div class="alert alert-success">
  <p>{{ \Session::get('success') }}</p>
</div><br /> @endif
<!-- display the warning status -->
@if (\Session::has('warning'))
<div class="alert alert-warning">
  <p>{{ \Session::get('warning') }}</p>
</div><br /> @endif


<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 ">
    	<div class="card">
    	  <div class="card-header">User profile</div>
    	  <div class="card-body">
    	   <table class="table table-bordered">
    	   	<tr>
    	   		<th>ID</th>
    	   		<td>{{ $user->id }}</td>
    	   	</tr>
    	   	<tr>
    	   		<th>Name</th>
    	   		<td>{{ $user->name }}</td>
    	   	</tr>
    	   	<tr>
    	   		<th>Email</th>
    	   		<td>{{ $user->email }}</td>
    	   	</tr>
    	   	
    	   </table>
    	  </div>
    	</div>
    </div>
  </div>
</div>
@endsection
